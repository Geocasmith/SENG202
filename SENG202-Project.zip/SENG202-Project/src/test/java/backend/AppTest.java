package backend;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


/**
 * Unit test for simple App.
 */
public class AppTest {
    boolean x;

    /**
     * Rigorous Tests :-)
     */
    @BeforeEach
    public void init() {x = true;}
    @Test
    public void testApp()
    {
        assertTrue(x);
    }
    @Test
    public void GeorgeTestApp()
    {
        assertTrue(x);
    }
    @Test
    public void JonathanTestApp()
    {
        assertTrue(x);
    }
    @Test
    public void BedeTestApp()
    {
        assertTrue(x);
    }
    @Test
    public void DanielTestApp()
    {
        assertTrue(true);
    }
}
